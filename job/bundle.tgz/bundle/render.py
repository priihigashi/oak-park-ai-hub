import asyncio, sys, subprocess, json
from playwright.async_api import async_playwright
SITE='/home/claude/reel3/site'
FPS=30
PREP='''()=>{window.loop=()=>{};try{audio.pause()}catch(e){}
const r=document.createElement('img');r.id='rclip';r.className='main';r.style.cssText='position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:50% 62%;display:none';clip.parentNode.appendChild(r);}'''
FRAME='''async (t)=>{render(t);const S=D.scenes[cur];
const dd=document.getElementById('doodle'),dl=document.getElementById('dllbl');
if(S.doodle&&S.panel.type!=='grid'&&S.panel.type!=='cycle'&&t>=S.s+0.3){dd.classList.add('draw');dl.classList.add('on')}
const r=document.getElementById('rclip');
if(S.panel.type==='video'){clip.style.visibility='hidden';r.style.display='block';const n=Math.max(1,Math.min(window.NCLIP,Math.floor((D.clipOff+t)*30)+1));const src='fr_clip/'+String(n).padStart(5,'0')+'.jpg';if(!r.src.endsWith(src))r.src=src}else{r.style.display='none'}
for(const a of document.getAnimations()){a.pause();const el=a.effect&&a.effect.target;if(!el||!el.closest){continue}
 const tm=a.effect.getComputedTiming();if(tm.iterations===Infinity){a.currentTime=(t*1000)%1e9;continue}
 let t0=S.s;const h=el.closest('[data-in]');if(h){t0=parseFloat(h.dataset.in);if(h.dataset.out&&t>=parseFloat(h.dataset.out))t0=parseFloat(h.dataset.out)}
 if(el.closest('#doodle')||el.id==='dllbl')t0=S.s+0.3;const w=el.closest('.w');if(w)t0=+w.dataset.s;if(el.closest('#banner'))t0=50;
 a.currentTime=Math.max(0,(t-t0)*1000)}
await Promise.all([...document.images].filter(i=>i.offsetParent!==null&&!i.complete).map(i=>i.decode().catch(()=>{})));}'''
async def main(a,b,out):
    async with async_playwright() as p:
        br=await p.chromium.launch()
        pg=await br.new_page(viewport={'width':1080,'height':1920})
        await pg.goto('file://'+SITE+'/index.html')
        await pg.add_style_tag(content='.wrap{padding:0!important;max-width:none}.wrap>h1,.wrap>.sub,.tabs,.ctrl{display:none!important}.grid{display:block}.phone{max-width:none;width:1080px;border-radius:0}html,body{overflow:hidden;margin:0}')
        await pg.evaluate('fit()');await pg.wait_for_timeout(2500)
        await pg.evaluate(PREP)
        n=int(subprocess.check_output('ls '+SITE+'/fr_clip | wc -l',shell=True))
        await pg.evaluate(f'window.NCLIP={n}')
        ff=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','image2pipe','-c:v','mjpeg','-framerate',str(FPS),'-i','-','-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p',out],stdin=subprocess.PIPE)
        for f in range(a,b):
            t=f/FPS
            await pg.evaluate(FRAME,t)
            img=await pg.screenshot(type='jpeg',quality=92,clip={'x':0,'y':0,'width':1080,'height':1920})
            ff.stdin.write(img)
        ff.stdin.close();ff.wait();await br.close()
asyncio.run(main(int(sys.argv[1]),int(sys.argv[2]),sys.argv[3]))
