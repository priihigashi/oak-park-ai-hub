set -e
W=$GITHUB_WORKSPACE
sudo mkdir -p /home/claude && sudo chown $(whoami) /home/claude
ln -sfn $W /home/claude/br
mkdir -p /home/claude/reel3/site /home/claude/reel3/tmp /home/claude/v3
B=$W/job/bundle
cp $B/texts.json /home/claude/v3/ ; cp $B/template.html /home/claude/reel3/
cp $W/out/clip_plantou.mp4 $W/out/clip_plantou_poster.jpg /home/claude/reel3/site/ || true
pip install -q opencv-python-headless playwright
python -m playwright install --with-deps chromium > /dev/null
python $B/crop.py
cd /home/claude/reel3 && python $B/build.py a investigations > /dev/null && python $B/build.py s investigations > /dev/null && python $B/gen.py s && python $B/gen.py a && python $B/page.py
S=/home/claude/reel3/site
mkdir -p $S/fr_clip && ffmpeg -loglevel error -y -i $S/clip_plantou.mp4 -vf fps=30 -q:v 3 $S/fr_clip/%05d.jpg
TOTAL=$(python -c "import json;print(json.load(open('/home/claude/reel3/timeline_s.json'))['total'])")
N=$(python -c "print(int($TOTAL*30))")
Q=$((N/4))
python $B/render.py 0 $Q /tmp/p0.mkv & python $B/render.py $Q $((2*Q)) /tmp/p1.mkv & python $B/render.py $((2*Q)) $((3*Q)) /tmp/p2.mkv & python $B/render.py $((3*Q)) $N /tmp/p3.mkv & wait
printf "file '/tmp/p0.mkv'\nfile '/tmp/p1.mkv'\nfile '/tmp/p2.mkv'\nfile '/tmp/p3.mkv'\n" > /tmp/list.txt
ffmpeg -loglevel error -y -f concat -safe 0 -i /tmp/list.txt -c copy /tmp/v.mkv
ffmpeg -loglevel error -y -i /tmp/v.mkv -i $S/track_s_investigations.mp3 -filter_complex "[0:v]setpts=PTS/1.05[v];[1:a]atempo=1.05[a]" -map "[v]" -map "[a]" -r 30 -c:v libx264 -preset medium -crf 22 -maxrate 2800k -bufsize 5600k -pix_fmt yuv420p -c:a aac -b:a 160k -movflags +faststart -shortest $W/out/reel_plantou_v3.mp4
python $B/cover.py $S/index.html $W/out/capa_plantou_v3.jpg
ls -la $W/out/reel_plantou_v3.mp4 $W/out/capa_plantou_v3.jpg
