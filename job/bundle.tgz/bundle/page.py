import json, html
CLIP_OFF = 0.85
data = {'clipOff': CLIP_OFF, 'voices': {}}
scenes_html = ''
for V in ['s', 'a']:
    T = json.load(open(f'/home/claude/reel3/timeline_{V}.json'))
    S = json.load(open(f'/home/claude/reel3/scenes_{V}.json'))
    data['voices'][V] = {'total': T['total'], 'cap': T['cap'], 'scenes': [{k: v for k, v in s.items() if k != 'top'} for s in S]}
    scenes_html += '\n'.join(f'<div class="scene" data-v="{V}" data-i="{i}">{s["top"]}</div>' for i, s in enumerate(S))

CAPTION = """COMPARTILHA NOS STORIES 📲 Dica: cria uma lista de Melhores Amigos com a família e manda pra lá.

Saíram 8 manchetes pra dizer que "a conta da eleição já chegou". Fui ver a data de cada uma.

2 são falsas. 2 são exageradas. 2 já estavam decididas antes do dia 25. 2 são verdade pela metade.

Cuidado com a desinformação. Quase nunca é mentira do zero: é um pedaço de verdade montado pra gerar revolta. É notícia velha com data nova, previsão vendida como certeza e verdade sem contexto.

Antes de compartilhar, olha a data e quem decidiu.

Vídeo original: @nikolasferreiradm"""

COMMENT = """COMENTA: você já recebeu notícia velha como se fosse nova? Conta aqui 👇
.
.
Abertura: o vídeo dele começa com a música "Vermelho" e fala com quem votou no PT. No 2º turno, o governo atual teve 69,37% dos votos no Nordeste (TSE via Brasil 61, 25/10/2026). Três dias antes, em 23/10, o ministro José Guimarães (PT, esquerda) já tinha acusado o deputado de preconceito contra nordestinos por outro vídeo (O Antagonista, 23/10/2026).
.
Fontes de cada manchete:
1. Escala 6x1: Agência Gov, 28/10/2026 (Emenda 141 promulgada em 16/10). Voto de Nikolas a favor: Metrópoles, 27/05/2026
2. Taxa das blusinhas: Metrópoles; Money Times, 16/06/2026 (reforma tributária de 2023). Voto de Nikolas contra a reforma: Itatiaia, 06/07/2023
3. Luz no Nordeste: projeção preliminar da Aneel (Folha do Estado e Portal Mais 360, 27/10/2026); divisão do encargo CDE entre regiões: Lei 13.360/2016
4. Diesel: Poder360 e O Globo, 27/10/2026 (desconto de R$ 2,12 renovado por 30 dias); preço médio nos postos: ANP via Jornal Pequeno, 29/10/2026
5. Gol: Panrotas e Itatiaia, 14/10/2026
6. Gás do Povo: Agência Gov e MDS, 28/10/2026
7. Regulação das redes: Pleno News e Metrópoles, 26/10/2026
8. Dilma: Estadão via Terra, 27/10/2026 (decisão do TRF-1, dez/2025)
Os mesmos pontos também foram checados por @joao_pacifico e @armandinhoh.
Música: "Investigations", Kevin MacLeod (incompetech.com), licença CC BY 4.0.
.
Prompt pra checar com IA (manda junto com o print da matéria):
Verifique a informação desta matéria e considere:
1. Data: quando isso foi decidido ou anunciado pela 1ª vez? É notícia nova ou antiga?
2. Quem decide: governo, Congresso, Justiça, estado ou empresa privada?
3. Número: é a conta toda ou só uma parte? É previsão ou certeza?
4. Se é lei: quem propôs, se foi votada na Câmara e no Senado, se teve votação nominal e como votaram direita e esquerda.
5. Checagem: o que dizem Lupa, Aos Fatos e fontes oficiais?
6. O que a manchete deixou de fora?
Não dê opinião: responda só com fatos, datas e fontes com link. No fim, diga se é verdade, falso, exagerado, antigo ou sem contexto."""

COLLABS = "@brasilforadacaverna @projeto.contraponto @joao_pacifico"

SOURCES = [
 ('Recuo na 6x1', 'Falso', 'Agência Gov, 28/10/2026', 'https://agenciagov.ebc.com.br/noticias/202610/governo-alerta-para-fake-news-nas-redes-sociais-envolvendo-fim-da-escala-6x1-e-programas-sociais'),
 ('Taxa das blusinhas em 2027', 'Já estava decidido', 'Money Times, 16/06/2026', 'https://www.moneytimes.com.br/governo-ira-voltar-com-a-taxa-das-blusinhas-nova-cobranca-sobre-compras-internacionais-esta-no-radar/'),
 ('Luz no Nordeste em 2027', 'Exagerado', 'Folha do Estado (projeção Aneel)', 'https://www.folhadoestado.com.br/economia/conta-de-luz-deve-ficar-mais-cara-no-norte-e-nordeste-em-2027-preve-aneel/644811'),
 ('Diesel a R$ 10', 'Exagerado', 'Poder360, 27/10/2026', 'https://www.poder360.com.br/poder-governo/governo-prorroga-subvencao-ao-diesel-por-30-dias/'),
 ('Gol corta voos pros EUA', 'Anunciado antes', 'Panrotas, 14/10/2026', 'https://www.panrotas.com.br/aviacao/empresas/2026/10/gol-anuncia-suspensao-de-voos-para-miami-orlando-e-punta-cana-em-2027_232832.html'),
 ('Corte no Gás do Povo', 'Falso', 'Agência Gov, 28/10/2026', 'https://agenciagov.ebc.com.br/noticias/202610/governo-alerta-para-fake-news-nas-redes-sociais-envolvendo-fim-da-escala-6x1-e-programas-sociais'),
 ('Regulação das redes', 'Verdade, sem contexto', 'Pleno News, 26/10/2026', 'https://pleno.news/brasil/politica-nacional/em-discurso-apos-ser-eleito-lula-fala-em-regular-as-redes-sociais.html'),
 ('Dilma: R$ 17,5 mil por mês', 'Verdade, sem contexto', 'Terra / Estadão, 27/10/2026', 'https://www.terra.com.br/noticias/brasil/politica/dilma-tera-indenizacao-de-r-175-mil-por-mes-e-r-66-milhoes-em-retroativos-por-perseguicao-na-ditadura,91c50e482e67a2e75b7c6b21eeb40e0d5b5o6ih0.html'),
('Voto de Nikolas na PEC 6x1', 'Votou a favor', 'Metrópoles, 27/05/2026', 'https://www.metropoles.com/brasil/saiba-como-nikolas-ferreira-votou-na-pec-do-fim-da-escala-6x1'),
 ('Voto de Nikolas na reforma tributária', 'Votou contra', 'Itatiaia, 06/07/2023', 'https://www.itatiaia.com.br/politica/reforma-tributaria-saiba-como-votaram-os-deputados-de-minas-gerais/'),
 ('Por que a luz sobe no Nordeste', 'Divisão da CDE', 'Lei 13.360/2016', 'https://www2.camara.leg.br/legin/fed/lei/2016/lei-13360-17-novembro-2016-783915-publicacaooriginal-151400-pl.html'),
 ('Preço do diesel nos postos', 'R$ 6,99 em média', 'Jornal Pequeno (ANP), 29/10/2026', 'https://jornalpequeno.com.br/2026/10/29/diesel-sobe-8-por-cento-subsidio-icms-2027/'),
]
src_html = ''.join(f'<li><div><b>{i+1}. {html.escape(a)}</b><span class="v">{html.escape(b)}</span></div><a href="{u}" target="_blank" rel="noopener">{html.escape(c)}</a></li>' for i, (a, b, c, u) in enumerate(SOURCES))

page = open('/home/claude/reel3/template.html').read()
page = (page.replace('/*DATA*/', json.dumps(data, ensure_ascii=False))
        .replace('<!--SCENES-->', scenes_html)
        .replace('%%CAPTION%%', html.escape(CAPTION))
        .replace('%%COMMENT%%', html.escape(COMMENT))
        .replace('%%COLLABS%%', html.escape(COLLABS))
        .replace('<!--SOURCES-->', src_html))
open('/home/claude/reel3/site/index.html', 'w').write(page)
print('ok', len(page))
