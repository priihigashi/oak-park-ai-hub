import json, subprocess, os, re, html, shutil, sys
VOICE = sys.argv[1] if len(sys.argv) > 1 else 's'
MUSIC = sys.argv[2] if len(sys.argv) > 2 else 'wallpaper'
OUT = '/home/claude/br/out'
SITE = '/home/claude/reel3/site'
os.makedirs(SITE, exist_ok=True)
sh = lambda c: subprocess.run(c, shell=True, check=True)
dur = lambda f: float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',f]).decode())

CLIP_OFF = 0.85          # start inside clip_plantou.mp4 ("E olha, o plantio...")
CLIP_LEN = 7.5   # audio taken from the full original so the last 'PT' is not cut
GAP = 0.32
texts = json.load(open('/home/claude/v3/texts.json'))
PFX = {'s': 'v', 'a': 'w'}[VOICE]
DETAIL_N = 8; DETAIL_DUR = 2.6

# ---------- audio timeline
segs = []  # (key, start, dur)
t = 0.0
segs.append(('hook', t, CLIP_LEN)); t += CLIP_LEN + 0.25
for k in [f's{i:02d}' for i in range(1, 13)]:
    d = dur(f'{OUT}/{PFX}{k[1:]}.mp3'); segs.append((k, t, d)); t += d + GAP
DETAIL_START = round(t + 0.1, 2)
t13 = round(DETAIL_START + DETAIL_N * DETAIL_DUR + 0.3, 2)
d13 = dur(f'{OUT}/{PFX}13.mp3'); segs.append(('s13', t13, d13))
PROMPT_HOLD = 6.0
TOTAL = round(t13 + d13 + PROMPT_HOLD, 2)

tmp = '/home/claude/reel3/tmp'; os.makedirs(tmp, exist_ok=True)
sh(f'ffmpeg -y -loglevel error -ss {28.6+CLIP_OFF} -i {OUT}/original_leve.mp4 -t {CLIP_LEN} -vn -af highpass=f=90,acompressor,loudnorm=I=-14,afade=t=out:st={CLIP_LEN-0.25}:d=0.25 -ac 2 -ar 44100 {tmp}/hook.wav')
inputs = []; filt = []
for i, (k, s, d) in enumerate(segs):
    f = f'{tmp}/hook.wav' if k == 'hook' else f'{OUT}/{PFX}{k[1:]}.mp3'
    inputs.append(f'-i {f}')
    vol = '0.9' if k == 'hook' else '1.0'
    filt.append(f'[{i}:a]aresample=44100,aformat=channel_layouts=stereo,volume={vol},adelay={int(s*1000)}|{int(s*1000)}[a{i}]')
n = len(segs)
inputs.append(f'-stream_loop -1 -i {OUT}/music_{MUSIC}.mp3')
vexpr = f"if(lt(t,{DETAIL_START-0.3}),0.065,if(lt(t,{t13-0.3}),0.21,if(lt(t,{t13+d13}),0.065,0.2)))"
filt.append(f"[{n}:a]atrim=0:{TOTAL},asetpts=N/SR/TB,aresample=44100,aformat=channel_layouts=stereo,volume='{vexpr}':eval=frame,afade=t=in:d=1.5,afade=t=out:st={TOTAL-1.5}:d=1.4[a{n}]")
segs_for_mix = n + 1
mix = ''.join(f'[a{i}]' for i in range(segs_for_mix))
filt.append(f'{mix}amix=inputs={segs_for_mix}:normalize=0,apad,atrim=0:{TOTAL},loudnorm=I=-15:TP=-1.5[out]')
sh(f'ffmpeg -y -loglevel error {" ".join(inputs)} -filter_complex "{";".join(filt)}" -map "[out]" -c:a libmp3lame -b:a 128k {SITE}/track_{VOICE}_{MUSIC}.mp3')

# ---------- words (absolute)
DISPLAY = [
    (['vinte','e','cinco'], '25'), (['dois','mil','e','vinte','e','sete'], '2027'),
    (['dois','mil','e','vinte','e','três'], '2023'), (['seis','por','um'], '6x1'),
    (['dezesseis'], '16'), (['nove','por','cento'], '9%'), (['vinte'], '20'),
    (['zero','vírgula','setenta','e','sete','por','cento'], '0,77%'), (['duzentos','reais'], 'R$\u00a0200'),
    (['um','real','e','meio'], 'R$\u00a01,50'), (['dez','reais'], 'R$\u00a010'), (['trinta','dias'], '30\u00a0dias'),
    (['catorze'], '14'), (['oito'], '8'), (['três'], '3'), (['duas'], '2'),
]
def norm(w): return re.sub(r'[^\wà-ú]', '', w.lower())
words = []  # {w, s, e}
for k, s, d in segs:
    if k == 'hook':
        wh = json.load(open(f'{OUT}/speech.wav.whisper.json'))['words']
        a = 28.6 + CLIP_OFF
        for x in wh:
            if x['s'] >= a - 0.05 and x['e'] <= a + CLIP_LEN + 0.05:
                words.append({'w': x['w'], 's': round(s + x['s'] - a, 3), 'e': round(s + x['e'] - a, 3), 'k': k})
        continue
    bw = json.load(open(f'{OUT}/{PFX}{k[1:]}.words.json')); toks = texts[k].split()
    i = 0
    while i < len(bw):
        done = False
        for pat, disp in DISPLAY:
            n = len(pat)
            if [norm(x) for x in toks[i:i+n]] == pat:
                tail = re.sub(r'[\wà-úÀ-Ú]+', '', toks[i+n-1])  # trailing punctuation
                words.append({'w': disp + tail, 's': round(s + bw[i]['s'], 3), 'e': round(s + bw[i+n-1]['e'], 3), 'k': k})
                i += n; done = True; break
        if not done:
            words.append({'w': toks[i], 's': round(s + bw[i]['s'], 3), 'e': round(s + bw[i]['e'], 3), 'k': k}); i += 1

# ---------- caption pages: hand-set, 2 lines each ("/" = line, "|" = page)
LAY = {
'hook': "E olha, o plantio / é opcional. | Tiveram a opção de / não plantar PT, | mas plantaram PT, / vai colher PT.",
's01': "Ele juntou 8 manchetes / pra dizer que a conta | da eleição já chegou. / Quase tudo já estava | marcado antes do dia 25, / o dia do segundo turno, | ou nem é / verdade.",
's02': "Recuo no fim da escala / 6x1, aquela de trabalhar | seis dias pra folgar um? / Isso é falso. | A emenda, que é uma / mudança na Constituição, | saiu no dia 16, antes / do segundo turno, | e não mudou / uma vírgula.",
's03': "Taxa das blusinhas, / o imposto das compras | pequenas em sites de fora, / em 2027? | Vem da reforma tributária / de 2023, que juntou | vários impostos num só, / votada pelo Congresso | onde ele é deputado. / Cerca de 9%, não 20. | Notícia / de junho.",
's04': "Luz mais cara no Nordeste: / a previsão da Aneel, | a agência que cuida / da energia, é de 0,77%. | Numa conta de R$ 200, / cerca de R$ 1,50. | E no Sul e no Sudeste, / a previsão é de queda.",
's05': "Diesel a R$ 10? / O desconto que o governo | paga em cada litro / tinha prazo marcado | desde setembro, e já foi / renovado por mais 30 dias.",
's06': "A Gol, que é empresa / privada, anunciou o corte | dos voos no dia 14, / antes da eleição, | porque o combustível / de avião dobrou de preço | no mundo todo / com a guerra no Irã.",
's07': "Corte no Gás do Povo, / o botijão de graça | pras famílias mais pobres? / Isso é falso. | O pagamento continua, / e o dinheiro de 2027 | já está / no orçamento.",
's08': "Regulação das redes, / que é criar regras | pras plataformas / responderem por crime, | como na vida real: / verdade, mas o governo | já defendia isso / há anos.",
's09': "Dilma: também é verdade, / mas quem mandou pagar | foi a Justiça, em dezembro / do ano passado, | como indenização por ela / ter sido presa e torturada | na ditadura. O ministério / só cumpriu a ordem.",
's10': "Placar: 2 falsas, / 2 exageradas, | 2 decididas antes / da eleição | e 2 verdades / pela metade.",
's11': "Cuidado com a / desinformação. | Quase nunca é mentira / do zero: ela pega | um pedaço de verdade / e monta pra gerar revolta. | É notícia velha / com data nova, | previsão vendida / como certeza | e verdade / sem contexto. | Antes de compartilhar, / olha a data | e quem / decidiu.",
's12': "Quer os detalhes / de cada uma? | Dá uma pausa no vídeo / ou tira um print da tela.",
's13': "A maioria de nós lê a / manchete e já repassa. | E se você joga / no Google ou numa | inteligência artificial, / ela pode dizer | que é verdade, sem / avisar que a notícia | é antiga ou quem aprovou. / Então tira print | deste prompt e manda / junto com a matéria.",
}
pages=[]
for k in [s[0] for s in segs]:
    ws=[w for w in words if w['k']==k]; i=0
    for pg in LAY[k].split('|'):
        P=[]
        for ln in pg.split('/'):
            toks=ln.replace('R$ ','R$\u00a0').replace('30 dias','30\u00a0dias').split(' '); toks=[x for x in toks if x]; line=[]
            for tk in toks:
                w=ws[i]
                if norm(w['w'])!=norm(tk):
                    # allow whisper spelling differences in hook only
                    if k!='hook': raise SystemExit(f'caption mismatch {k}: {tk} vs {w["w"]}')
                line.append(dict(w, w=tk)); i+=1
            P.append(line)
        pages.append(P)
    if i!=len(ws): raise SystemExit(f'{k}: {len(ws)-i} words left {[w["w"] for w in ws[i:]]}')
cap = []
for pg in pages:
    s0 = pg[0][0]['s']; e0 = pg[-1][-1]['e']
    cap.append({'s': s0, 'e': e0, 'lines': [[[w['w'], w['s'], w['e']] for w in ln] for ln in pg]})
for i in range(len(cap) - 1):
    cap[i]['e'] = max(cap[i]['e'], min(cap[i+1]['s'], cap[i]['e'] + 0.6))

def at(key, word, nth=1):
    """absolute time of nth occurrence of word (normalized prefix match) in segment key"""
    c = 0
    for w in words:
        if w['k'] == key and norm(w['w']).startswith(norm(word)):
            c += 1
            if c == nth: return w['s']
    raise SystemExit(f'trigger not found {key} {word}')
SEG = {k: (s, d) for k, s, d in segs}

json.dump({'t13': t13, 'detail_start': DETAIL_START, 'detail_dur': DETAIL_DUR, 'total': TOTAL, 'segs': segs, 'cap': cap, 'words': words}, open(f'/home/claude/reel3/timeline_{VOICE}.json', 'w'), ensure_ascii=False)
print('TOTAL', TOTAL)
for k, s, d in segs: print(k, round(s, 2), round(d, 2))
for c in cap: print(round(c['s'],2), ' / '.join(' '.join(w[0] for w in ln) for ln in c['lines']))
