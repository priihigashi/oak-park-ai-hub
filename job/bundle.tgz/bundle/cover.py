import asyncio,sys
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch();pg=await b.new_page(viewport={'width':1080,'height':1920})
        await pg.goto('file://'+sys.argv[1])
        await pg.evaluate('''()=>{const s=document.getElementById('covstage');document.body.innerHTML='';document.body.style.margin=0;s.style.transform='none';s.style.position='fixed';document.body.appendChild(s)}''')
        await pg.wait_for_timeout(1500)
        await pg.screenshot(path=sys.argv[2],type='jpeg',quality=92,clip={'x':0,'y':0,'width':1080,'height':1920})
        await b.close()
asyncio.run(main())
