import cv2
m={1:4,2:12,3:15,4:21,5:27,6:32,7:40,8:46}
for i,j in m.items():
    f=cv2.imread(f'/home/claude/br/out/fr/f_{j:03d}.jpg')
    c=cv2.resize(f[40:760,100:620],(624,864),interpolation=cv2.INTER_CUBIC)
    cv2.imwrite(f'/home/claude/reel3/site/h{i}.jpg',c,[cv2.IMWRITE_JPEG_QUALITY,88])
