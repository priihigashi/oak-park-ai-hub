import json, re, html, sys
VOICE = sys.argv[1] if len(sys.argv) > 1 else 's'
T = json.load(open(f'/home/claude/reel3/timeline_{VOICE}.json'))
W = T['words']; SEG = {k: (s, d) for k, s, d in T['segs']}
def norm(w): return re.sub(r'[^\wà-ú]', '', w.lower())
def at(k, word, nth=1, d=0.0):
    c = 0
    for w in W:
        if w['k'] == k and norm(w['w']).startswith(norm(word)):
            c += 1
            if c == nth: return round(w['s'] + d, 2)
    raise SystemExit(f'trigger not found: {k} {word}')
def st(k, d=0.0): return round(SEG[k][0] + d, 2)
def en(k): return round(SEG[k][0] + SEG[k][1] + 0.32, 2)

SQUID = '''<svg class="squid" viewBox="0 0 120 130" aria-hidden="true"><g stroke="#fff" stroke-width="7" stroke-linejoin="round" paint-order="stroke">
<path d="M60 8 C30 8 18 34 22 58 C25 76 36 84 60 84 C84 84 95 76 98 58 C102 34 90 8 60 8Z" fill="#FF8FB8"/>
<path d="M30 80 q-8 20 2 34 M45 84 q-6 22 4 36 M60 86 q0 22 0 36 M75 84 q6 22 -4 36 M90 80 q8 20 -2 34" fill="none" stroke="#FF8FB8" stroke-width="9" stroke-linecap="round"/></g>
<path d="M30 80 q-8 20 2 34 M45 84 q-6 22 4 36 M60 86 q0 22 0 36 M75 84 q6 22 -4 36 M90 80 q8 20 -2 34" fill="none" stroke="#FF8FB8" stroke-width="9" stroke-linecap="round"/>
<path d="M60 8 C30 8 18 34 22 58 C25 76 36 84 60 84 C84 84 95 76 98 58 C102 34 90 8 60 8Z" fill="#FF8FB8"/>
<ellipse cx="46" cy="52" rx="7" ry="9" fill="#1a1a1a"/><ellipse cx="74" cy="52" rx="7" ry="9" fill="#1a1a1a"/>
<circle cx="48" cy="48" r="2.6" fill="#fff"/><circle cx="76" cy="48" r="2.6" fill="#fff"/>
<ellipse cx="36" cy="66" rx="7" ry="4" fill="#ff5f8f" opacity=".6"/><ellipse cx="84" cy="66" rx="7" ry="4" fill="#ff5f8f" opacity=".6"/>
<path d="M53 66 q7 6 14 0" fill="none" stroke="#1a1a1a" stroke-width="3.5" stroke-linecap="round"/></svg>'''

def slot(*items): return '<div class="slot">' + ''.join(items) + '</div>'
def stamp(kind, t):
    lab = {'falso': 'Falso', 'decidido': 'Já estava decidido', 'anunciado': 'Anunciado antes', 'exagerado': 'Exagerado', 'verdade': 'Verdade, sem contexto'}[kind]
    return f'<div class="stamp st-{kind} pop" data-in="{t}">{lab}</div>'
def quote(txt, t): return f'<div class="quote rise" data-in="{t}"><span class="q-lbl">A manchete dele</span><span class="q-txt">“{txt}”</span></div>'
def counter(n, t): return f'<div class="count rise" data-in="{t}">{n}<span>/8</span></div>'
def timeline(points, t, step=0.25):
    # points: (label_top, label_bottom, kind) kind: ok / vote / after
    n = len(points); out = [f'<div class="tl rise" data-in="{t}"><div class="tl-line"></div>']
    for i, (a, b, kind) in enumerate(points):
        x = 15 + i * (70 / (n - 1))
        out.append(f'<div class="tl-pt tl-{kind} pop" data-in="{round(t + 0.15 + i*step, 2)}" style="left:{x}%"><i></i><b>{a}</b><span>{b}</span></div>')
    out.append('</div>'); return ''.join(out)

S = []  # scenes
def scene(k, bg, top, panel, src, s=None, e=None, doodle=True):
    S.append(dict(k=k, bg=bg, top=top, panel=panel, src=src, s=st(k) if s is None else s, e=en(k) if e is None else e, doodle=doodle))

# ---- hook
k = 'hook'
scene(k, 'ink', f'''
<div class="chip chip-r rise" data-in="0.15"><span class="dot"></span>Nikolas Ferreira · PL · direita</div>
<div class="guide rise" data-in="0.35">Dois dias depois da eleição, o&nbsp;deputado federal postou:</div>
<div class="big xl slam" data-in="0.6">Plantou PT, <span class="hl hl-g">vai colher PT</span></div>
{slot('<div class="fine rise" data-in="1.4" data-out="3.8">Mais de 45 milhões de views em um dia</div>', '<div class="fine rise" data-in="3.8">Recado pra quem votou no PT: 69% do Nordeste. Quem fala é deputado, pago por todos.</div>')}''',
 {'type': 'video'}, 'Vídeo: @nikolasferreiradm, 28/10/2026 · Votos: TSE via Brasil 61, 25/10/2026', doodle=False)

k = 's01'
scene(k, 'theme', f'''
<div class="row-num"><div class="num slam" data-in="{at(k,'8')}">8</div><div class="num-lbl rise" data-in="{at(k,'manchetes')}">manchetes pra dizer que <b>a conta já chegou</b></div></div>
<div class="big md rise" data-in="{at(k,'Quase')}">Quase tudo já estava marcado antes do <span class="hl hl-w">dia 25</span></div>
<div class="mid rise" data-in="{at(k,'nem')}">Ou nem é verdade.</div>''',
 {'type': 'cycle', 'from': at(k, 'manchetes')}, 'Vídeo: @nikolasferreiradm, 28/10/2026')

k = 's02'
scene(k, 'paper', f"""
<div class="head">{counter(1, st(k,0.05))}{quote('Governo recua sobre fim da escala 6x1', st(k,0.1))}</div>
{stamp('falso', at(k,'Falso'))}
{slot(f'<div class="mid rise" data-in="{at(k,'aquela')}" data-out="{at(k,'emenda')}">6x1 = <b class="c-ok">6 dias</b> de trabalho, <b class="c-ok">1</b> de folga</div>', f'<div class="big lg rise" data-in="{at(k,'emenda')}">Promulgada em <span class="hl hl-k">16/out</span></div>')}
<div class="fine rise" data-in="{at(k,'mudança')}">Emenda = mudança na Constituição. Depois de promulgada, nem o presidente pode mudar.</div>
{timeline([('27/mai','Ele votou sim','ok'),('16/out','Promulgada','ok'),('25/out','2º turno','vote')], at(k,'antes'))}
""",
 {'type': 'img', 'src': 'h1.jpg'}, 'Fontes: Agência Gov, 28/10/2026 · Voto: Metrópoles, 27/05/2026')

k = 's03'
scene(k, 'ink', f"""
<div class="head">{counter(2, st(k,0.05))}{quote('Taxa das blusinhas pode voltar com novo imposto', st(k,0.1))}</div>
{stamp('decidido', at(k,'Vem'))}
{slot(f'<div class="mid rise" data-in="{at(k,'imposto')}" data-out="{at(k,'Vem')}">O imposto das compras pequenas em sites de fora</div>', f'<div class="big lg rise" data-in="{at(k,'reforma')}">Reforma de <span class="hl hl-g">2023</span></div>')}
{slot(f'<div class="fine rise" data-in="{at(k,'juntou')}" data-out="{at(k,'Cerca')}">Reforma tributária = a mudança que juntou vários impostos num só. O imposto novo (CBS) vale igual pra loja daqui e de fora.</div>', f'<div class="mid rise" data-in="{at(k,'Cerca')}">Cerca de <b class="c-theme">9%</b>, não os 20% da taxa antiga.</div>')}
{timeline([('jul/2023','Ele votou não','ok'),('jun/2026','Já era notícia','ok'),('25/out','2º turno','vote')], at(k,'votada'))}
""",
 {'type': 'img', 'src': 'h2.jpg'}, 'Fontes: Metrópoles; Money Times, 16/06/2026 · Voto: Itatiaia, 06/07/2023')

k = 's04'
scene(k, 'theme', f"""
<div class="head">{counter(3, st(k,0.05))}{quote('Conta de luz deve ficar mais cara no Nordeste em 2027', st(k,0.1))}</div>
{stamp('exagerado', at(k,'0,77'))}
{slot(f'<div class="mid rise" data-in="{at(k,'agência')}" data-out="{at(k,'0,77')}">Aneel = a agência que cuida da energia e calcula a conta de luz</div>', f'<div class="big xxl slam" data-in="{at(k,'0,77')}">0,77%</div>')}
{slot(f'<div class="mid rise" data-in="{at(k,'Numa')}" data-out="{at(k,'Sul')}">Numa conta de R$&nbsp;200, sobe cerca de <span class="hl hl-w">R$&nbsp;1,50.</span></div>', f'<div class="cmp rise" data-in="{at(k,'Sul')}"><div><b>+0,77%</b><span>Norte e Nordeste</span></div><div><b>−0,62%</b><span>Sul, Sudeste e Centro&#8209;Oeste</span></div></div>')}
""",
 {'type': 'img', 'src': 'h3.jpg'}, 'Fonte: previsão preliminar da Aneel (Folha do Estado, 27/10/2026)')

k = 's05'
scene(k, 'paper', f"""
<div class="head">{counter(4, st(k,0.05))}{quote('Diesel pode chegar a R$&nbsp;10,00 o litro', st(k,0.1))}</div>
{stamp('exagerado', at(k,'renovado'))}
<div class="big lg rise" data-in="{at(k,'desconto')}">Desconto de <span class="hl hl-k">R$&nbsp;2,12</span> por litro</div>
<div class="fine rise" data-in="{at(k,'paga')}">O governo paga esse valor pra quem produz e importa o diesel, e eles baixam o preço.</div>
{timeline([('25/set','Prazo marcado','ok'),('25/out','2º turno','vote'),('27/out','Renovado','ok')], at(k,'setembro'))}
""",
 {'type': 'img', 'src': 'h4.jpg'}, 'Fonte: Poder360 e O Globo, 27/10/2026')

k = 's06'
scene(k, 'ink', f"""
<div class="head">{counter(5, st(k,0.05))}{quote('Gol cancela rotas; DF sem voo direto para os EUA', st(k,0.1))}</div>
{stamp('anunciado', at(k,'anunciou'))}
{slot(f'<div class="mid rise" data-in="{at(k,'privada')}" data-out="{at(k,'14')}">Empresa privada: <b class="c-theme">a própria Gol escolhe as rotas</b></div>', f'<div class="big lg rise" data-in="{at(k,'14')}">Já em <span class="hl hl-g">14/out</span></div>')}
{timeline([('14/out','Gol anuncia','ok'),('25/out','2º turno','vote')], at(k,'antes'))}
<div class="mid rise" data-in="{at(k,'combustível')}">Motivo: o combustível de avião <b class="c-theme">dobrou de preço</b>.</div>""",
 {'type': 'img', 'src': 'h5.jpg'}, 'Fonte: Panrotas e Itatiaia, 14/10/2026')

k = 's07'
scene(k, 'theme', f"""
<div class="head">{counter(6, st(k,0.05))}{quote('Auxílio Gás pode sofrer novos cortes', st(k,0.1))}</div>
{stamp('falso', at(k,'Falso'))}
{slot(f'<div class="mid rise" data-in="{at(k,'botijão')}" data-out="{at(k,'pagamento')}">Gás do Povo = <b>botijão de 13 kg de graça</b> pras famílias mais pobres</div>', f'<div class="big lg rise" data-in="{at(k,'pagamento')}">O pagamento <span class="hl hl-w">continua</span></div>')}
<div class="mid rise" data-in="{at(k,'2027')}">O dinheiro de 2027 já está no orçamento que foi pro Congresso.</div>""",
 {'type': 'img', 'src': 'h6.jpg'}, 'Fonte: Agência Gov e MDS, 28/10/2026')

k = 's08'
scene(k, 'paper', f"""
<div class="head">{counter(7, st(k,0.05))}{quote('Regulação das redes no 1º discurso após a reeleição', st(k,0.1))}</div>
{stamp('verdade', at(k,'verdade'))}
{slot(f'<div class="mid rise" data-in="{at(k,'criar')}" data-out="{at(k,'verdade')}">Regulação = regras pra Instagram, TikTok e cia. <b>responderem por crime</b></div>', f'<div class="chip chip-l chip-squid rise" data-in="{at(k,'governo')}">{SQUID}Governo atual · PT · esquerda</div>')}
<div class="big lg rise" data-in="{at(k,'defendia')}">Mas <span class="hl hl-k">não é novo</span></div>
<div class="fine rise" data-in="{at(k,'anos')}">No discurso, não houve lei nova. O debate inclui desinformação em massa, como as 8 manchetes deste vídeo.</div>""",
 {'type': 'img', 'src': 'h7.jpg', 'squid': True}, 'Fontes: Pleno News e Metrópoles, 26/10/2026')

k = 's09'
scene(k, 'ink', f"""
<div class="head">{counter(8, st(k,0.05))}{quote('Dilma receberá R$&nbsp;17,5 mil mensais', st(k,0.1))}</div>
{stamp('verdade', at(k,'verdade'))}
<div class="chip chip-l rise" data-in="{at(k,'Dilma')}"><span class="dot"></span>Dilma Rousseff · PT · esquerda</div>
<div class="big lg rise" data-in="{at(k,'Justiça')}">Ordem da <span class="hl hl-g">Justiça</span></div>
{timeline([('dez/2025','Ordem do TRF-1','ok'),('21/out','Portaria','ok'),('25/out','2º turno','vote')], at(k,'dezembro'))}
<div class="fine rise" data-in="{at(k,'indenização')}">Indenização = pagamento por um dano. A regra é uma lei de 2002, de FHC (PSDB, centro-direita).</div>""",
 {'type': 'img', 'src': 'h8.jpg'}, 'Fonte: Estadão via Terra, 27/10/2026 · TRF-1 · Lei 10.559/2002')

k = 's10'
scene(k, 'theme', f'''
<div class="big lg rise" data-in="{st(k,0.05)}">Placar das 8</div>
<div class="score">
 <div class="tile t-f pop" data-in="{at(k,'falsas')}"><b>2</b><span>Falsas</span></div>
 <div class="tile t-e pop" data-in="{at(k,'exageradas')}"><b>2</b><span>Exageradas</span></div>
 <div class="tile t-d pop" data-in="{at(k,'decididas')}"><b>2</b><span>Decididas antes</span></div>
 <div class="tile t-v pop" data-in="{at(k,'verdades')}"><b>2</b><span>Meias verdades</span></div>
</div>''',
 {'type': 'grid'}, 'Fontes completas no 1º comentário')

k = 's11'
scene(k, 'ink', f'''
<div class="guide rise" data-in="{st(k,0.05)}">Cuidado com a</div>
<div class="big lg slam" data-in="{at(k,'desinformação')}"><span class="hl hl-g">Desinformação</span></div>
<div class="mid rise" data-in="{at(k,'Quase')}">Pedaço de verdade montado pra gerar revolta. É:</div>
<div class="techs">
 <div class="tech rise" data-in="{at(k,'velha',d=-0.3)}"><i><svg viewBox="0 0 48 48"><rect x="6" y="10" width="36" height="32" rx="5" fill="none" stroke="currentColor" stroke-width="5"/><path d="M6 20h36M16 5v10M32 5v10" stroke="currentColor" stroke-width="5" stroke-linecap="round"/></svg></i><div><b>Notícia velha com data nova</b><span>Blusinhas, Gol</span></div></div>
 <div class="tech rise" data-in="{at(k,'previsão')}"><i><svg viewBox="0 0 48 48"><path d="M6 38 L18 24 L26 30 L42 10" fill="none" stroke="currentColor" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/><path d="M33 10h9v9" fill="none" stroke="currentColor" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/></svg></i><div><b>Previsão vendida como certeza</b><span>Luz, diesel</span></div></div>
 <div class="tech rise" data-in="{at(k,'verdade')}"><i><svg viewBox="0 0 48 48"><circle cx="12" cy="36" r="7" fill="none" stroke="currentColor" stroke-width="5"/><circle cx="36" cy="36" r="7" fill="none" stroke="currentColor" stroke-width="5"/><path d="M17 31 L38 6 M31 31 L10 6" stroke="currentColor" stroke-width="5" stroke-linecap="round"/></svg></i><div><b>Verdade sem contexto</b><span>Redes, Dilma</span></div></div>
</div>''',
 {'type': 'grid'}, 'Fontes completas no 1º comentário', e=at(k,'Antes'))
scene(k, 'theme', f'''
<div class="guide rise" data-in="{at(k,'Antes')}">Antes de compartilhar:</div>
<div class="check slam" data-in="{at(k,'data',d=-0.2)}"><i>✓</i>Olha a <span class="hl hl-w">data</span></div>
<div class="check slam" data-in="{at(k,'quem')}"><i>✓</i>Vê <span class="hl hl-w">quem decidiu</span></div>''',
 {'type': 'grid'}, 'Fontes completas no 1º comentário', s=at(k,'Antes'))

k = 's12'
CAM = '<svg viewBox="0 0 48 48" class="cam"><rect x="4" y="12" width="40" height="28" rx="6" fill="none" stroke="currentColor" stroke-width="5"/><circle cx="24" cy="26" r="8" fill="none" stroke="currentColor" stroke-width="5"/><path d="M16 12l4-6h8l4 6" fill="none" stroke="currentColor" stroke-width="5" stroke-linejoin="round"/></svg>'
scene(k, 'ink', f'''
<div class="guide rise" data-in="{st(k,0.05)}">Agora, com calma:</div>
<div class="big lg slam" data-in="{at(k,'detalhes')}">Explicações <span class="hl hl-g">mais detalhadas</span></div>
<div class="mid rise" data-in="{at(k,'Pausa')}">{CAM} Pausa ou tira print pra ler</div>''',
 {'type': 'grid'}, 'Fontes completas no 1º comentário', e=T['detail_start'])

k = 's13'
PROMPT = ['Data: quando isso foi decidido ou anunciado pela 1ª vez? É notícia nova ou antiga?',
 'Quem decide: governo, Congresso, Justiça, estado ou empresa privada?',
 'Número: é a conta toda ou só uma parte? É previsão ou certeza?',
 'Se é lei: quem propôs, se foi votada na Câmara e no Senado, se teve votação nominal e como votaram direita e esquerda.',
 'Checagem: o que dizem Lupa, Aos Fatos e fontes oficiais?',
 'O que a manchete deixou de fora?']
scene(k, 'ink', f'''
<div class="guide rise" data-in="{st(k,0.05)}">Uma dica antes de ir:</div>
<div class="big lg slam" data-in="{at(k,'Google')}">Google e IA também <span class="hl hl-g">deixam passar</span></div>
<div class="mid rise" data-in="{at(k,'avisar')}">Dizem que é verdade e não avisam que a notícia é antiga nem quem aprovou.</div>''',
 {'type': 'grid'}, 'Fontes completas no 1º comentário', e=at(k,'Então'))
lis = ''.join(f'<li>{b}</li>' for b in PROMPT)
S.append(dict(k='prompt', bg='paper', top=f'''
<div class="det">
 <div class="det-h"><span class="det-n" style="font-size:64px">{CAM} Tira print</span></div>
 <div class="pr-box"><div class="pr-lead">Cole na IA junto com o print da matéria:</div><div class="pr-q">Verifique a informação desta matéria e considere:</div><ol class="pr-l">{lis}</ol><div class="pr-q">Não dê opinião: responda só com fatos, datas e fontes com link. No fim, diga se é verdade, falso, exagerado, antigo ou sem contexto.</div></div>
</div>''', panel={'type': 'none'}, src='', s=at(k,'Então'), e=T['total'], doodle=False))

DET = [
 ('falso', 'Fim da escala 6x1', ['Emenda Constitucional 141, promulgada pelo Congresso em 16/out, 9 dias antes do 2º turno.', 'Depois de promulgada, o presidente não pode vetar nem mudar o texto.', 'O próprio Nikolas votou a favor na Câmara, em 27/mai (461 a 19).'], 'Fontes: Agência Gov, 28/10/2026; Metrópoles, 27/05/2026'),
 ('decidido', 'Taxa das blusinhas', ['O imposto de 20% das compras de até US$ 50 foi zerado em maio de 2026.', 'Em 2027 entra a CBS, da reforma tributária de 2023, que vale pra compra daqui e de fora.', 'Estimativa: cerca de 9%. O valor final ainda depende de regulamentação.', 'Nikolas votou contra a reforma tributária em 2023.'], 'Fontes: Metrópoles; Money Times, 16/06/2026; Itatiaia, 06/07/2023'),
 ('exagerado', 'Conta de luz em 2027', ['Previsão: +0,77% no Norte e Nordeste, −0,62% no resto. Os 7,3% são só de um encargo (CDE).', 'Por que lá sobe: lei de 2016 (Temer, MDB, centro) iguala aos poucos, até 2030, quanto cada região paga desse encargo.', 'Risco extra: o Super El Niño, aquecimento do Pacífico que muda as chuvas. Menos água nas hidrelétricas e mais risco de queimadas no Norte e Nordeste.'], 'Fontes: Aneel via Folha do Estado, 27/10/2026; Lei 13.360/2016; A Crítica, jun/2026'),
 ('exagerado', 'Diesel a R$&nbsp;10', ['Desconto de R$&nbsp;2,12 por litro, pago a quem produz e importa diesel.', 'Venceu em 26/out e foi renovado em 27/out por mais 30 dias.', 'Mesmo assim subiu nos postos: média de R$&nbsp;6,99 (ANP, 18 a 24/out), 8% a mais que em setembro, por causa do petróleo caro com a guerra no Irã.'], 'Fontes: Poder360; O Globo; ANP via Jornal Pequeno, 27 e 29/10/2026'),
 ('anunciado', 'Gol e os voos pros EUA', ['Anúncio em 14/out, 11 dias antes do 2º turno.', 'Saem só os voos diretos de Brasília pra Miami, Orlando e Buenos Aires, a partir de fev/2027.', 'Ainda dá pra ir com conexão. O combustível já é cerca de 40% do custo da Gol.'], 'Fontes: Panrotas, 14/10/2026; g1, 26/10/2026'),
 ('falso', 'Corte no Gás do Povo', ['Recarga grátis do botijão de 13 kg pra cerca de 15 milhões de famílias.', 'Orçamento de 2026 garantido. O de 2027 já está na proposta enviada ao Congresso.', 'O governo desmentiu o corte em nota oficial no dia 27/out.'], 'Fontes: Agência Gov; MDS, 28/10/2026'),
 ('verdade', 'Regulação das redes', ['Fala no discurso da vitória: crime na internet tem que ser tratado como crime na vida real.', 'Não detalhou nenhuma medida nova.', 'O tema já era defendido pelo governo antes da eleição. O projeto mais conhecido, o PL 2630 (PL das Fake News), é de 2020: passou no Senado e parou na Câmara em 2023.', 'O debate inclui o que fazer com desinformação em massa, como as 8 manchetes que você acabou de ver.'], 'Fontes: Pleno News; Metrópoles, 26/10/2026; Câmara (PL 2630/2020)'),
 ('verdade', 'Indenização da Dilma', ['R$&nbsp;17.562,80 por mês. O retroativo calculado é de R$&nbsp;6,6 milhões, com desconto do que ela já recebeu.', 'Ordem do TRF-1, um tribunal federal, em dez/2025. A portaria foi assinada em 21/out.', 'Base: Lei 10.559, de 2002, a mesma que indeniza outros perseguidos pela ditadura.'], 'Fontes: Terra/Estadão, 27/10/2026; TRF-1'),
]
for i, (kind, title, bullets, src) in enumerate(DET):
    s0 = round(T['detail_start'] + i * T['detail_dur'], 2)
    lis = ''.join(f'<li>{b}</li>' for b in bullets)
    S.append(dict(k='det', bg=['paper','ink'][i % 2], top=f'''
<div class="det">
 <div class="det-h"><span class="det-n">{i+1}<small>/8</small></span>{stamp(kind, s0).replace(' pop"', '"').replace('class="stamp', 'class="stamp in-row')}</div>
 <div class="big md">{title}</div>
 <ul class="det-l">{lis}</ul>
</div>''', panel={'type': 'none'}, src=src, s=s0, e=round(s0 + T['detail_dur'], 2) if i < 7 else T['t13'], doodle=False))

json.dump(S, open(f'/home/claude/reel3/scenes_{VOICE}.json', 'w'), ensure_ascii=False)
print(len(S), 'scenes')
