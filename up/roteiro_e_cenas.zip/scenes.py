# Cenas do reel "Placar da checagem" — último debate do 2º turno (Constituição de 88 / SUS)
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from tts import TTS_TEXT

TIMELINE = [
 ('clip','c1'), ('vo','n1'), ('clip','c2'), ('vo','n2'), ('clip','c2b'), ('vo','n2b'),
 ('clip','c3'), ('vo','n3'), ('clip','c4'), ('vo','n4'), 
 ('clip','c6'), ('vo','n6'), ('clip','c7'), ('vo','n7'), ('vo','n8'), ('vo','nb1'), ('vo','nb2'), ('vo','nb3')
]

CLIP_CTX = {
 'c1': ('Pergunta do Flávio', 'Por que você votou contra a Constituição de 88?'),
 'c2': ('Resposta do presidente', 'Não falou da Constituição. Falou da Covid'),
 'c2b': ('O presidente continua', 'Sobre a cloroquina'),
 'c3': ('O presidente continua', 'Sobre Bolsonaro na pandemia'),
 'c4': ('Pergunta do presidente', 'Como você vai bancar o SUS?'),
 'c5': ('Resposta do Flávio', 'Sobre o atentado de 2018'),
 'c6': ('Resposta do Flávio', 'Sobre a fila do câncer'),
 'c7': ('Flávio continua', 'Sobre as Santas Casas'),
}

CLIP_SPEAKER = {'c2':'pres','c2b':'pres','c3':'pres','c4':'pres'}

FIX = {'Por':'Porque', 'sofocando,':'sufocando,', 'estava':'tava', 'para':'pra'}
DROP_NEXT_AFTER = {('c2','Por'):'que'}  # "Por que" -> "Porque"

POINTS = [
 ('n1','meio','meio','flavio'),
 ('n2','Verdade.','verdade','pres'),
 ('n2b','Verdade.','verdade','pres'),
 ('n3','verdade.','verdade','pres'),
 ('n4','Verdade,','verdade','pres'),
 ('n6','Verdade','verdade','flavio'),
 ('n7','fake.','fake','flavio'),
]

SRC = {
 'nb1': 'Fonte: Ministério da Saúde (SI-PNI/RNDS), via IEPS e TabNet. 2024 e 2025 preliminares',
 'nb2': 'Fonte: ABTO, Registro Brasileiro de Transplantes (2016 a 2025)',
 'nb3': 'Fonte: Ministério da Saúde, via Poder360 (27/12/2025) e Fundação Perseu Abramo',
 'n0': 'Debate do 2º turno, 23/10/2026',
 'n1': 'Fonte: Diário da Constituinte (23/09/1988), Fundação Perseu Abramo e Exame (23/10/2026)',
 'n2': 'Fonte: Agência Lupa (23/10/2026), UOL e g1',
 'n2b': 'Fonte: Defesa à CPI da Covid (via O Povo), Morning Consult (mai/2020), Hutukara (via Poder360) e Ministério da Saúde (via O Globo, fev/2023)',
 'n3': 'Fonte: lives de 18/03 e 06/05/2021 (via Agência Lupa, 23/10/2026)',
 'n4': 'Fonte: debate da Fundação FHC (2019), via A Tarde e BP Money (out/2026)',
 'n5': 'Fonte: Santa Casa de Juiz de Fora (set/2018)',
 'n6': 'Fonte: TCU, relatório de jun/2026 (via Agência Lupa, 23/10/2026)',
 'n7': 'Fonte: Futuro da Saúde (fev e jun/2026) e Folha de Pernambuco (15/07/2026)',
 'n8': 'Fontes completas no primeiro comentário',
}

def stamp(kind, label=None):
    lab = {'fake':'FAKE','meio':'MEIO TERMO','verdade':'VERDADE'}[kind]
    return f'<div class="stamp st-{kind}"><span class="prov">Provavelmente</span><b>{label or lab}</b></div>'

def quote(txt, who='Ele disse'):
    return f'<div class="quote"><span class="qk">{who}</span><span class="qt">“{txt}”</span></div>'

JAIR = '<img class="mini" src="heads/jair.png" alt="">'
SQ = '<span class="mini sq">__SQUID__</span>'

PANELS = {
 'n0': [
  ('votou', '<div class="big b0">Votou contra o <span class="mk">SUS</span></div>'),
  ('t:2.6', '<div class="big b0">Debochou da <span class="mk">Covid</span></div>'),
  ('t:3.4', '<div class="squid-row"><div class="squid-ico">__SQUID__</div><div class="big b0">Nada pelas <span class="mk">Santas Casas</span></div></div>'),
  ('debate.#2', '<div class="guide">Vamos conferir o debate.</div>'),
 ],
 'n1': [
  ('t:0', quote('Por que votou contra a Constituição?', 'Flávio perguntou')),
  ('meio', stamp('meio')),
  ('16', '<div class="check ok"><b>✓</b><span>22/set/1988: os 16 do PT votaram não. Em 5/out, assinaram</span></div>'),
  ('SUS,', '<div class="check no"><b>✗</b><span>Contra o SUS? Não. O PT defendia o SUS</span></div>'),
  ('40', '<div class="tiles"><div class="tile"><div class="tn">40h</div><div class="tl">O PT queria</div></div>'
         '<div class="tile late" data-at="44,"><div class="tn">44h</div><div class="tl">Ficou</div></div>'
         '<div class="tile late" data-at="reforma"><div class="tn">✗</div><div class="tl">Reforma agrária</div></div></div>'),
  ('trabalhador.', '<div class="fine big-fine">Queriam ainda mais direitos e mais tempo livre pro trabalhador.</div>'),
 ],
 'n2': [
  ('t:0', quote('Quem tomasse vacina ia virar jacaré', 'Governo atual disse')),
  ('Verdade.', stamp('verdade')),
  ('dezembro', f'<div class="row"><div class="num">17/12/2020</div><div class="lbl">{JAIR} Bolsonaro, sobre a Pfizer:<br><span class="cont">“Se você virar um jacaré, é problema seu”</span></div></div>'),
  ('recusou', '<div class="check no"><b>✗</b><span>2020: governo recusou ofertas da Pfizer</span></div>'),
  ('janeiro', '<div class="fine big-fine">A vacinação no Brasil só começou em 17 de janeiro de 2021.</div>'),
 ],
 'n2b': [
  ('t:0', quote('Ele inventou remédio (...) cloroquina', 'Governo atual disse')),
  ('Verdade.', stamp('verdade')),
  ('levou', '<div class="check ok"><b>✓</b><span>Levou pra Covid, como o presidente dos EUA e a base MAGA</span></div>'),
  ('Exército', '<div class="row"><div class="num">3,2 mi</div><div class="lbl">Comprimidos feitos pelo Exército<br><span class="cont">em 2020, a pedido do governo Bolsonaro</span></div></div>'),
  ('garimpeiros', '<div class="check no"><b>!</b><span>2021: garimpo Yanomami +46%, remédio de malária vendido no garimpo</span></div>'),
  ('faltou', '<div class="fine">2022: faltou cloroquina pra malária Yanomami. OMS: não serve pra Covid.</div>'),
 ],
 'n3': [
  ('t:0', quote('Ele preferiu debochar e imitar as pessoas sufocando', 'Governo atual disse')),
  ('verdade.', stamp('verdade')),
  ('lives', '<div class="tiles"><div class="tile"><div class="tn">18/03</div><div class="tl">Live de 2021: imitou falta de ar</div></div>'
            '<div class="tile late" data-at="maio,"><div class="tn">06/05</div><div class="tl">Outra live, mesma imitação</div></div>'
            '<div class="tile late" data-at="mentira,"><div class="tn">✗</div><div class="tl">Flávio negou no debate</div></div></div>'),
  ('existem.', '<div class="fine big-fine">Ele criticava a orientação de só ir ao hospital com falta de ar.</div>'),
 ],
 'n4': [
  ('t:0', quote('Você tá colocando uma pessoa que não quer colocar dinheiro no SUS', 'Governo atual disse')),
  ('Verdade,', stamp('verdade')),
  ('Lottenberg,', '<div class="head-row"><div class="head-wrap"><img class="head" src="heads/lottenberg.png" alt=""></div><div class="lbl">Cláudio Lottenberg<br><span class="cont">Médico, sem partido · escolhido do Flávio (PL · direita) pra Saúde</span></div></div>'),
  ('2019:', '<div class="fine big-fine">Em 2019: “Eu não colocaria nada mais, a não ser que a gente esgotasse” os recursos que já existem, gastando melhor.</div>'),
 ],
 'n5': [
  ('t:0', quote('Foi o SUS que salvou o presidente Bolsonaro', 'Flávio disse')),
  ('Verdade.', stamp('verdade')),
  ('facada,', f'<div class="row"><div class="num">06/09/2018</div><div class="lbl">{JAIR} Operado pelo SUS<br><span class="cont">na Santa Casa de Juiz de Fora</span></div></div>'),
  ('Ponto', '<div class="big">Ponto pro <span class="mk">Flávio</span></div>'),
 ],
 'n6': [
  ('t:0', quote('Câncer de tireoide: espera de 700 dias', 'Flávio disse')),
  ('Verdade', stamp('verdade')),
  ('gráfico:', '<div class="chart"><div class="ct">Espera pela cirurgia de câncer de tireoide (dias)</div><div class="cplot" style="grid-template-columns:repeat(4,1fr);gap:40px;height:110px">'
     '<div class="rzone" style="width:calc(25% - 24px)"><span>Bolsonaro</span></div>'
     '<div class="lzone" style="left:calc(25% + 16px)"><span class="sq">__SQUID__</span><span>Governo atual · PT · esquerda</span></div>'
     '<div class="cb b" style="--h:112px;--i:0"><span class="cv">1.121</span><i></i><span class="cy">2022</span></div>'
     '<div class="cb r" style="--h:42px;--i:1"><span class="cv">421</span><i></i><span class="cy">2023</span></div>'
     '<div class="cb r" style="--h:8px;--i:2"><span class="cv">75</span><i></i><span class="cy">2024</span></div>'
     '<div class="cb r" style="--h:72px;--i:3"><span class="cv">719</span><i></i><span class="cy">2025</span></div></div></div>'),
  ('curva.', '<div class="fine">TCU: dado “anômalo”. 5 estados com 55% das cirurgias quase não informam.</div>'),
 ],
 'n7': [
  ('t:0', quote('Você não fez nada pra reduzir a dívida das Santas Casas', 'Flávio disse')),
  ('fake.', stamp('fake')),
  ('fevereiro', '<div class="row"><div class="num">Fev/2026</div><div class="lbl">Crédito da Caixa com FGTS<br><span class="cont">pras Santas Casas e filantrópicos</span></div></div>'),
  ('3', '<div class="tiles"><div class="tile"><div class="tn">R$ 3 bi</div><div class="tl">Pra 140 hospitais</div></div>'
        '<div class="tile late" data-at="122"><div class="tn">122</div><div class="tl">Contratos pra renegociar dívida</div></div>'
        '<div class="tile late" data-at="juros"><div class="tn">18→12%</div><div class="tl">Juros ao ano</div></div></div>'),
 ],
 'n8': [
  ('Flávio:', '<div class="frow"><div class="fwho"><img class="whoimg" src="heads/flavio.png" alt=""><span>Flávio<br><small class="cd">PL · direita</small></span></div><div class="final"><div class="fc f-fake"><b>1</b><span>Fake</span></div><div class="fc f-meio"><b>1</b><span>Meio termo</span></div><div class="fc f-verd"><b>1</b><span>Verdade</span></div></div></div>'),
  ('presidente:', '<div class="frow"><div class="fwho"><span class="whoimg sqw">__SQUID__</span><span>Gov. atual<br><small class="ce">PT · esquerda</small></span></div><div class="final"><div class="fc f-fake"><b>0</b><span>Fake</span></div><div class="fc f-meio"><b>0</b><span>Meio termo</span></div><div class="fc f-verd"><b>4</b><span>Verdade</span></div></div></div>'),
  ('errou', '<div class="guide">Nessas frases, quem mais errou foi o Flávio.</div>'),
  ('Manda', '<div class="fine">O placar vale para as 7 frases checadas, não para o debate inteiro.</div>'),
 ],
}

SPOKEN = [
 (['meio','termo'],'meio termo'), (['um','fake'],'1 fake'), (['três','verdades'],'3 verdades'), (['quatro','verdades'],'4 verdades'), (['duas','verdades'],'2 verdades'), (['uma','verdade'],'1 verdade'), (['um','meio','termo'],'1 meio termo'),
]

def yearchart(title, data, fmt=lambda v: f'{v:.0f}', right_until=2022, unit=''):
    """data: list of (year, value). Right-wing years (<= right_until) blue + shaded zone; current gov red."""
    vmax = max(v for _, v in data)
    n = len(data)
    nr = sum(1 for y, _ in data if y <= right_until)
    bars = ''
    for i, (y, v) in enumerate(data):
        h = max(6, round(100 * v / vmax))
        c = 'b' if y <= right_until else 'r'
        bars += f'<div class="cb {c}" style="--h:{h}px;--i:{i}"><span class="cv">{fmt(v)}{unit}</span><i></i><span class="cy">{str(y)[2:] if n > 8 else y}</span></div>'
    zw = f'calc({nr} * (100% + 12px) / {n} - 9px)'
    return (f'<div class="chart"><div class="ct">{title}</div><div class="cplot" style="grid-template-columns:repeat({n},1fr);gap:12px;height:132px">'
            f'<div class="rzone" style="width:{zw}"><span>Temer e Bolsonaro</span></div>'
            f'<div class="lzone" style="left:calc({zw} + 8px)"><span class="sq">__SQUID__</span><span>Gov. atual</span></div>'
            f'{bars}</div></div>')

def classif(lbl):
    return f'<div class="stamp st-verdade"><span class="prov">Classificação</span><b>{lbl}</b></div>'
br=lambda v: f'{v:.1f}'.replace('.',',')
VAC=[(2016,95.4),(2017,86.2),(2018,92.6),(2019,93.1),(2020,79.5),(2021,71.5),(2022,80.7),(2023,86.9),(2024,95.7),(2025,92.9)]
RIM=[(2016,5271),(2017,5923),(2018,5984),(2019,6304),(2020,4830),(2021,4831),(2022,5406),(2023,6211),(2024,6325),(2025,6697)]
PANELS['nb1']=[
  ('t:0','<div class="quote"><span class="qk">Bônus · SUS</span><span class="qt">Vacina: cobertura da tríplice viral (%)</span></div>'),
  ('Vacina:', yearchart('Crianças vacinadas com a 1ª dose, por ano (%)', VAC, fmt=lambda v: f'{v:.0f}'.replace('.',','))),
  ('Melhorou.', classif('MELHOROU')),
  ('pandemia.', '<div class="fine">A queda começou em 2016. Meta: 95%. Em 2025 ficou um pouco abaixo.</div>'),
]
PANELS['nb2']=[
  ('t:0','<div class="quote"><span class="qk">Bônus · SUS</span><span class="qt">Transplantes de rim por ano</span></div>'),
  ('rim:', yearchart('Transplantes de rim por ano (mil)', RIM, fmt=lambda v: br(v/1000))),
  ('Melhorou.', classif('RECORDE')),
  ('recorde', '<div class="fine">2020 e 2021 caíram por causa da pandemia.</div>'),
]
PANELS['nb3']=[
  ('t:0','<div class="quote"><span class="qk">Bônus · SUS</span><span class="qt">Médicos no Mais Médicos</span></div>'),
  ('dobrou:', classif('DOBROU')),
  ('14', '<div class="tiles"><div class="tile"><div class="tn">13,7 mil</div><div class="tl">Começo de 2023</div></div><div class="tile late" data-at="27"><div class="tn">27,3 mil</div><div class="tl">2025</div></div><div class="tile late" data-at="2025."><div class="tn">+99%</div><div class="tl">Em 3 anos</div></div></div>'),
  ('2025.', '<div class="fine">Em 2016, antes da saída dos médicos cubanos, eram cerca de 18 mil.</div>'),
]
