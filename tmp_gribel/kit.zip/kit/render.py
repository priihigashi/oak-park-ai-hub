import sys,subprocess,json,math
from playwright.sync_api import sync_playwright
D=json.load(open('data.json'));FPS=30
import glob;NF=len(glob.glob('fr/*.jpg'))
import glob;NF=len(glob.glob('fr/*.jpg'))
import glob;NF=len(glob.glob('fr/*.jpg'))
a,b,out=float(sys.argv[1]),float(sys.argv[2]),sys.argv[3]
N0,N1=int(a*FPS),int(min(b,D['total'])*FPS)
ff=subprocess.Popen(['ffmpeg','-y','-loglevel','error','-f','image2pipe','-framerate',str(FPS),'-c:v','mjpeg','-i','-','-c:v','libx264','-preset','veryfast','-crf','19','-pix_fmt','yuv420p',out],stdin=subprocess.PIPE)
with sync_playwright() as p:
    br=p.chromium.launch();pg=br.new_page(viewport={'width':1080,'height':1920})
    pg.goto('http://localhost:8766/site/index.html');pg.wait_for_timeout(1200)
    pg.add_style_tag(content="html,body{overflow:hidden;padding:0!important;margin:0}.tabs,.ctrl{display:none!important}.wrap{max-width:none!important;gap:0}#phone{position:fixed!important;left:0;top:0;width:1080px!important;height:1920px;border-radius:0;box-shadow:none}#vid{visibility:hidden}#vimg{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:50% 0%}#vbox.paused #vimg{filter:grayscale(.85) brightness(.82)}*{transition:none!important}")
    pg.evaluate("()=>{window.requestAnimationFrame=()=>0;const i=document.createElement('img');i.id='vimg';const f=document.querySelector('#vbox .frame');f.insertBefore(i,f.firstChild);fit()}")
    w=pg.evaluate("()=>document.getElementById('stage').getBoundingClientRect().width");assert abs(w-1080)<1,w
    for n in range(N0,N1):
        t=n/FPS
        fi=pg.evaluate("t=>{renderAt(t);return Math.min(%d,Math.max(1,Math.round(vtimeAt(t)*30)+1))}"%NF,t)
        pg.evaluate("async f=>{const i=document.getElementById('vimg');const s='/fr/'+String(f).padStart(5,'0')+'.jpg';if(!i.src.endsWith(s)){i.src=s;try{await i.decode()}catch(e){}}}",fi)
        ff.stdin.write(pg.locator('#stage').screenshot(type='jpeg',quality=92))
    br.close()
ff.stdin.close();ff.wait()
