# Cenas do reel "Placar da checagem" (Flávio na GloboNews)
# Cada item da timeline: ('vo', chave) ou ('clip', chave)
# Para vo: painel com elementos; 'at' = palavra gatilho dentro da fala (#n = n-ésima), ou 't:segundos' relativo.

TIMELINE = [
 ('vo','n0'), ('clip','c1'), ('vo','n1'), ('clip','c2'), ('vo','n2'), ('clip','c2b'), ('vo','n3'),
 ('clip','c3'), ('vo','n4'), ('clip','c4'), ('vo','n5'), ('clip','c5'), ('vo','n6'),
 ('clip','c6'), ('vo','n7'), ('vo','n8')
]

CLIP_CTX = {
 'c1': ('Pergunta da repórter', 'Vai manter a política de combate ao desmatamento do governo atual?'),
 'c2': ('Flávio continua', 'Mesma resposta, segundos depois'),
 'c2b': ('A repórter corrige na hora', 'Ela lembra o dado de desmatamento do mês'),
 'c3': ('Flávio continua', 'Sobre o fogo no Amazonas'),
 'c4': ('Segunda pergunta', 'Vai manter a política para o Ibama e o ICMBio?'),
 'c5': ('Flávio sobre o Ibama', 'Ele fala de quem mora no Pará'),
 'c6': ('Terceira pergunta', 'Ibama e ICMBio devem aplicar a lei contra o desmatamento?'),
}

# quem fala no clipe (chip)
CLIP_SPEAKER = {'c2b': 'reporter'}

# Correções de palavras do Whisper (palavra original -> exibida)
FIX = {
 'Fox': 'focos', 'incendios': 'de incêndio', 'gestos': 'registros', 'trans': 'Transamazônica', 'amazônica.': '',
 'IBAMA': 'Ibama', 'ICMB': 'ICMBio', 'ICMB,': 'ICMBio,', 'ICMB?': 'ICMBio?', 'clarecer': 'esclarecer',
}

# Placar: em qual palavra cada ponto cai (fala, palavra, tipo)
POINTS = [
 ('n1','Recorde','fake'),
 ('n2','Desmatamento?','fake'),
 ('n3','queimada','fake'),
 ('n4','parte','meio'),
 ('n5','plano','verdade'),
 ('n6','verdade:','verdade'),
 ('n6','retiradas','meio'),
 ('n7','travado.','fake'),
]

SRC = {
 'n1': 'Fonte: Inpe/BDQueimadas via Poder360 (20/10), Agência Brasil (13/10) e SBT News (22/10/2026)',
 'n2': 'Fonte: Inpe/Prodes (série consolidada e estimativa 2026 de 16/10/2026)',
 'n3': 'Fonte: Agência Brasil (16/10/2026), Inpe e Ministério do Meio Ambiente',
 'n4': 'Fonte: Ministério da Integração, Senasp/MJ, Fato Amazônico (11/10) e Amazônia Real (out/2026)',
 'n5': 'Fonte: plano de governo (via SBT News, 16/10) e Inpe/Deter via Observatório do Clima (07/08/2026)',
 'n6': 'Fonte: Agência Brasil, Repórter Brasil e MapBiomas',
 'n7': 'Fonte: Ibama e Petrobras, 20/10/2025 (via InfoMoney e Money Times)',
 'n8': 'Fontes completas no primeiro comentário',
}

def stamp(kind, label=None):
    lab = {'fake':'FAKE','meio':'MEIO TERMO','verdade':'VERDADE'}[kind]
    return f'<div class="stamp st-{kind}"><span class="prov">Provavelmente</span><b>{label or lab}</b></div>'

def quote(txt):
    return f'<div class="quote"><span class="qk">Ele disse</span><span class="qt">“{txt}”</span></div>'

PANELS = {
 'n0': [
  ('desmatamento', '<div class="big b0">Não combate <span class="mk">desmatamento</span></div>'),
  ('queimada', '<div class="big b0">Não combate <span class="mk">queimada</span></div>'),
  ('abandonou', '<div class="squid-row"><div class="squid-ico">__SQUID__</div><div class="big b0">Abandonou o <span class="mk">Amazonas</span></div></div>'),
  ('verificar.', '<div class="guide">Vamos verificar.</div>'),
 ],
 'n1': [
  ('t:0', quote('O fogo neste outubro vai superar todos os registros da história')),
  ('Recorde', stamp('fake')),
  ('quatro', '<div class="tiles"><div class="tile"><div class="tn">+271%</div><div class="tl">Amazonas, 1 a 10/out, contra 2025</div></div>'
             '<div class="tile late" data-at="doze"><div class="tn">−12%</div><div class="tl">No ano, contra a média do Inpe</div></div>'
             '<div class="tile late" data-at="sessenta"><div class="tn">−67%</div><div class="tl">No ano, contra 2024</div></div></div>'),
  ('oito', '<div class="fine">78% dos focos de 1 a 19/out estavam em imóveis rurais do Cadastro Ambiental Rural.</div>'),
 ],
 'n2': [
  ('t:0', quote('Não está combatendo desmatamento')),
  ('Desmatamento?', stamp('fake')),
  ('subiu', '<div class="chart"><div class="ct">Desmatamento na Amazônia por ano (km²)</div><div class="cplot"><div class="rzone"><span>Jair Bolsonaro · PL · direita</span></div><div class="lzone"><span class="sq">__SQUID__</span><span>Governo atual · PT · esquerda</span></div><div class="cb b" style="--h:101px;--i:0"><span class="cv">10,1 mil</span><i></i><span class="cy">2019</span></div><div class="cb b" style="--h:108px;--i:1"><span class="cv">10,9 mil</span><i></i><span class="cy">2020</span></div><div class="cb b" style="--h:130px;--i:2"><span class="cv">13,0 mil</span><i></i><span class="cy">2021</span></div><div class="cb b" style="--h:116px;--i:3"><span class="cv">11,6 mil</span><i></i><span class="cy">2022</span></div><div class="cb r" style="--h:90px;--i:4"><span class="cv">9,1 mil</span><i></i><span class="cy">2023</span></div><div class="cb r" style="--h:65px;--i:5"><span class="cv">6,5 mil</span><i></i><span class="cy">2024</span></div><div class="cb r" style="--h:57px;--i:6"><span class="cv">5,7 mil</span><i></i><span class="cy">2025</span></div><div class="cb r" style="--h:33px;--i:7"><span class="cv">3,3 mil</span><i></i><span class="cy">2026</span></div></div></div>'),
  ('repórter', '<div class="fine">Prodes/Inpe. Cada ano vai de agosto a julho; 2026 é estimativa.</div>'),
 ],
 'n3': [
  ('t:0', quote('Não está combatendo queimada nenhuma')),
  ('queimada', stamp('fake')),
  ('onze', '<div class="tiles"><div class="tile"><div class="tn">11</div><div class="tl">Aeronaves no combate</div></div>'
           '<div class="tile late" data-at="trezentos"><div class="tn">300+</div><div class="tl">Focos apagados em 5 dias</div></div>'
           '<div class="tile late" data-at="Polícia"><div class="tn">PF</div><div class="tl">Investiga quem pôs fogo</div></div></div>'),
  ('multas', '<div class="fine">Ibama aplicou multas e o governo federal reconheceu emergência em 36 municípios (10/out).</div>'),
 ],
 'n4': [
  ('t:0', quote('O bombeiro pediu ajuda pro governo federal e não aconteceu')),
  ('parte', stamp('meio')),
  ('quatro', '<div class="check ok"><b>✓</b><span>1/out: pedido de 4 aeronaves pra doação negado</span></div>'),
  ('dispensado', '<div class="check no"><b>✗</b><span>30/set: o estado dispensou uma equipe federal</span></div>'),
  ('reconheceu', '<div class="row"><div class="num">10/out</div><div class="lbl">Emergência reconhecida: 6 aeronaves<br><span class="cont">no mesmo dia, + 2 da FAB no dia 11</span></div></div>'),
  ('Corpo', '<div class="fine big-fine">Avião só vai com emergência decretada. Bombeiro é do governo do estado.</div>'),
 ],
 'n5': [
  ('t:0', quote('Está no meu programa zerar o desmatamento ilegal até 2029')),
  ('plano', stamp('verdade')),
  ('retomar', '<div class="fine big-fine">O plano diz: “retomando o compromisso que já assumimos no governo Bolsonaro”.</div>'),
  ('quatro', '<div class="bars"><div class="bar"><span class="bl"><img class="mini" src="heads/jair.png" alt="">2019 a 2022 · Jair Bolsonaro</span><span class="bt blue" style="--w:100%"></span><span class="bv">33,4 mil km²</span></div>'
             '<div class="bar late" data-at="atual,"><span class="bl"><span class="mini sq">__SQUID__</span>2023 a 2026 · governo atual</span><span class="bt red" style="--w:58.8%"></span><span class="bv">19,6 mil km²</span></div></div>'),
 ],
 'n6': [
  ('t:0', quote('Ibama toma a propriedade na mão grande. Pessoas foram estimuladas a ir pro Pará')),
  ('verdade:', stamp('verdade','VERDADE')),
  ('ditadura,', '<div class="row"><div class="num">Anos 70</div><div class="lbl">A ditadura levou famílias<br><span class="cont">pra Transamazônica</span></div></div>'),
  ('retiradas', stamp('meio')),
  ('STF.', '<div class="check no"><b>!</b><span>Retirada de invasores de terras indígenas, por ordem do STF (2023)</span></div>'),
  ('Apyterewa', '<div class="fine">A TI Apyterewa foi a terra indígena mais desmatada do país de 2019 a 2022.</div>'),
 ],
 'n7': [
  ('t:0', quote('O Ibama trava, por questão ideológica, o petróleo na Foz do Amazonas')),
  ('travado.', stamp('fake')),
  ('liberou', '<div class="row"><div class="num">20/10/2025</div><div class="lbl">Ibama liberou a perfuração<br><span class="cont">no bloco FZA-M-059</span></div></div>'),
  ('Petrobras', '<div class="fine">Em 2023 o Ibama negou por falhas no plano de emergência. A Petrobras reforçou o plano e a licença saiu.</div>'),
 ],
 'n8': [
  ('quatro', '<div class="final"><div class="fc f-fake"><b>4</b><span>Fake</span></div><div class="fc f-meio late" data-at="dois"><b>2</b><span>Meio termo</span></div><div class="fc f-verd late" data-at="duas"><b>2</b><span>Verdade</span></div></div>'),
  ('Amanhã', '<div class="big">Amanhã tem<br><span class="mk">segundo turno</span></div>'),
  ('Manda', '<div class="guide">Manda pra quem ainda tá na dúvida.</div>'),
 ],
}

# Exibição de números na legenda (sequência falada -> texto exibido)
SPOKEN = [
 (['meio','termo'],'meio termo'), (['quatro','provavelmente','fake'],'4 provavelmente fake'),
 (['doze','por','cento'],'12%'), (['sessenta','e','sete','por','cento'],'67%'),
 (['onze'],'11'), (['trezentos'],'300'), (['quatro'],'4'), (['dois'],'2'), (['duas'],'2'), (['oito'],'8'), (['dez'],'10'), (['cinco'],'5'),
]

TTS_TEXT={'n0': 'Flávio Bolsonaro afirmou numa entrevista que o governo atual não combate desmatamento, não combate queimada e abandonou o Amazonas. Vamos verificar.', 'n1': 'Recorde da história? Os dados do Inpe não mostram isso. O fogo no Amazonas subiu muito em outubro, quase quatro vezes mais que em 2025. Mas no ano, o estado está doze por cento abaixo da média histórica, e sessenta e sete por cento abaixo de 2024. E quase oito em cada dez focos de outubro estão em fazendas cadastradas.', 'n2': 'Desmatamento? Segundo o Inpe, ele subiu no governo Bolsonaro e chegou a 13 mil quilômetros quadrados em 2021. No governo atual, caiu todo ano, até cerca de 3 mil, o menor desde 1988. A própria repórter corrigiu na hora.', 'n3': 'E queimada nenhuma? Teve força-tarefa com onze aeronaves, mais de trezentos focos apagados em cinco dias, multas do Ibama e a Polícia Federal investigando quem pôs fogo.', 'n4': 'Aqui tem uma parte certa: os bombeiros pediram quatro aeronaves pra doação, e o governo federal respondeu que não tinha pra doar. Mas o estado tinha dispensado uma equipe federal em 30 de setembro. E pra mandar avião, o estado precisava decretar emergência. O governo federal reconheceu no dia 10, e no mesmo dia chegaram seis aeronaves, mais dois aviões da FAB no dia seguinte. E lembra: o Corpo de Bombeiros é do governo do estado.', 'n5': 'Isso está mesmo no plano de governo dele. E o plano diz que vai retomar o compromisso do governo Bolsonaro. Nos quatro anos de Bolsonaro, os alertas de desmatamento somaram cerca de 33 mil quilômetros quadrados. No governo atual, cerca de 20 mil.', 'n6': 'Que o governo levou gente pra Transamazônica é verdade: foi a ditadura, nos anos 70. Já as retiradas perto de Altamira foram de invasores de terras indígenas, por ordem do STF. A Apyterewa era a terra indígena mais desmatada do país.', 'n7': 'E o petróleo na Foz do Amazonas não está travado. O Ibama liberou a perfuração em outubro de 2025, depois que a Petrobras reforçou o plano de emergência.', 'n8': 'Placar final: quatro provavelmente fake, dois meio termo e duas verdades. Amanhã tem segundo turno. Manda pra quem ainda tá na dúvida, e confere as fontes no primeiro comentário.'}
