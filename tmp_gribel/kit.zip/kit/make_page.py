import json,html
t=open('template.html').read(); D=open('data.json').read(); sq=open('squid.svg').read()
cover='''<div style="position:absolute;left:108px;right:108px;top:230px;display:flex;flex-direction:column;align-items:center;gap:30px;text-align:center">
<div style="font:900 40px var(--f-sans);letter-spacing:.1em;text-transform:uppercase;background:#141416;color:#fff;padding:12px 26px;border-radius:14px">Checagem frase por frase</div>
<img src="heads/flavio.png" alt="" style="width:400px;filter:drop-shadow(8px 0 0 #fff) drop-shadow(-8px 0 0 #fff) drop-shadow(0 8px 0 #fff) drop-shadow(0 -8px 0 #fff) drop-shadow(0 14px 20px rgba(0,0,0,.25));transform:rotate(-3deg)">
<div style="font:900 88px/1.02 var(--f-sans);letter-spacing:-.01em;white-space:nowrap">Flávio na entrevista:<br><span style="background:linear-gradient(#B48CFF,#B48CFF) no-repeat 0 85%/100% 36%">8 frases, 1 placar</span></div>
<div style="font:600 30px var(--f-sans);color:#6B6670">Provavelmente:</div>
<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:22px;width:100%">
<div style="border:5px solid #141416;border-radius:24px;padding:18px;background:#FF4A3D;color:#fff;font:900 36px var(--f-sans)">FAKE<div style="font:900 90px/1 var(--f-sans)">?</div></div>
<div style="border:5px solid #141416;border-radius:24px;padding:18px;background:#FFD34D;color:#141416;font:900 36px var(--f-sans)">MEIO TERMO<div style="font:900 90px/1 var(--f-sans)">?</div></div>
<div style="border:5px solid #141416;border-radius:24px;padding:18px;background:#1FAF5A;color:#fff;font:900 36px var(--f-sans)">VERDADE<div style="font:900 90px/1 var(--f-sans)">?</div></div>
</div></div>
<div style="position:absolute;left:0;right:0;top:1650px;text-align:center;font:700 30px var(--f-sans);opacity:.8">@tentandochegaratevoce</div>'''
cap='''COMPARTILHA NOS STORIES 🔁 E cria uma lista de Melhores Amigos pra chegar na família.

Flávio Bolsonaro falou em entrevista sobre desmatamento, queimadas e Ibama. A gente pausou a cada frase e conferiu com dados públicos: fake, meio termo ou verdade.

Amanhã é segundo turno. Assiste até o placar final.

#Eleições2026 #Amazônia #Desmatamento #Checagem'''
com='''COMENTA: qual frase do placar mais te surpreendeu? 👇
.
.
📚 FONTES
Inpe: Prodes (desmatamento, 16/10/2026), Deter (alertas) e BDQueimadas (focos)
Agência Brasil (13/10 e 16/10/2026)
Ministério da Integração e Senasp/MJ (ajuda ao Amazonas, out/2026)
Plano de governo do candidato (via SBT News, 16/10/2026)
Ibama e Petrobras: licença da Foz do Amazonas (20/10/2025)
📝 "Provavelmente" porque a checagem usa os dados públicos disponíveis até hoje. Sempre comparamos o mesmo período do ano.'''
import base64,glob
ff=''
for w in [500,600,700,800,900]:
    p=glob.glob(f'/home/claude/fl/fonts/fontsource-figtree-*/files/figtree-latin-{w}-normal.woff2')[0]
    ff+="@font-face{font-family:'Figtree';font-weight:%d;font-style:normal;font-display:block;src:url(data:font/woff2;base64,%s) format('woff2')}"%(w,base64.b64encode(open(p,'rb').read()).decode())
p=glob.glob('/home/claude/fl/fonts/fontsource-instrument-serif-*/files/instrument-serif-latin-400-italic.woff2')[0]
ff+="@font-face{font-family:'Instrument Serif';font-style:italic;font-weight:400;font-display:block;src:url(data:font/woff2;base64,%s) format('woff2')}"%base64.b64encode(open(p,'rb').read()).decode()
t=t.replace('<style>','<style>'+ff,1)
import re
t=re.sub(r'<link rel="preconnect"[^>]*>\n<link rel="stylesheet"[^>]*>\n','',t)
import os
t=t.replace('__BG__',os.environ.get('BG','branco')).replace('__MP4__',os.environ.get('MP4','')).replace('__MP4__',os.environ.get('MP4','')).replace('__MP4__',os.environ.get('MP4','')).replace('__DATA__',D).replace('const SQUID=`__SQUID__`','const SQUID=`'+sq+'`').replace('__COVER__',cover).replace('__CAPTION__',html.escape(cap)).replace('__COMMENT__',html.escape(com))
open('site/index.html','w').write(t)
print(len(t))
