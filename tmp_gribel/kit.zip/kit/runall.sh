cd /home/claude/fl/build
python3 render.py 0 90 p1.mkv & python3 render.py 90 176.985 p2.mkv & wait
printf "file 'p1.mkv'\nfile 'p2.mkv'\n" > parts.txt
ffmpeg -y -loglevel error -f concat -safe 0 -i parts.txt -i site/trilha.mp3 -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -shortest -movflags +faststart placar_flavio_v2.mp4
echo DONE
