import json,subprocess,time,sys
from playwright.sync_api import sync_playwright
D=json.load(open('data.json'))
srv=subprocess.Popen(['python3','-m','http.server','8765','-d','site'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);time.sleep(1)
times=set()
for s in D['segs']:
    times.add(round(s['start']+0.6,2)); times.add(round(s['start']+s['dur']-0.2,2))
    for e in s.get('els',[]): times.add(round(e['t']+0.9,2))
    for p in s['cap']: times.add(round((p['s']+p['e'])/2,2))
times=sorted(times)
JS='''(t)=>{render(t);const st=document.getElementById('stage');const sr=st.getBoundingClientRect();const k=sr.width/1080;
const P=r=>({x1:(r.left-sr.left)/k,y1:(r.top-sr.top)/k,x2:(r.right-sr.left)/k,y2:(r.bottom-sr.top)/k});
const errs=[];const boxes=[];
// text line rects
const walker=document.createTreeWalker(st,NodeFilter.SHOW_TEXT);let n;
while(n=walker.nextNode()){if(!n.textContent.trim())continue;const el=n.parentElement;if(el.closest('[hidden]'))continue;
 const cs=getComputedStyle(el.closest('.el')||el);if(el.closest('.el')&&!el.closest('.el').classList.contains('on'))continue;
 const lt=el.closest('.late');if(lt&&!lt.classList.contains('on'))continue;
 const r=document.createRange();r.selectNodeContents(n);for(const q of r.getClientRects()){const b=P(q);if(b.x2-b.x1<1)continue;
  if(b.x2>995||b.x1<85)errs.push('x '+n.textContent.trim().slice(0,30)+' '+b.x1.toFixed(0)+'-'+b.x2.toFixed(0));
  if(el.closest('#panel')&&b.y2>1422)errs.push('y '+n.textContent.trim().slice(0,30)+' '+b.y2.toFixed(0));
  boxes.push({id:(el.closest('#panel .el')?'P':'')+(el.closest('.L')||{}).id,b,txt:n.textContent.trim().slice(0,20)})}}
// overlap between different top-level layers
for(let i=0;i<boxes.length;i++)for(let j=i+1;j<boxes.length;j++){const a=boxes[i],c=boxes[j];if(a.id===c.id&&a.id!=='Ppanel')continue;if(a.id==='Ppanel'&&c.id==='Ppanel')continue;
 const o=Math.min(a.b.x2,c.b.x2)-Math.max(a.b.x1,c.b.x1),v=Math.min(a.b.y2,c.b.y2)-Math.max(a.b.y1,c.b.y1);if(o>4&&v>4)errs.push('overlap '+a.txt+' | '+c.txt)}
return errs}'''
JS2='''()=>{const errs=[];const st=document.getElementById('stage');const sr=st.getBoundingClientRect();const k=sr.width/1080;
for(const ps of document.querySelectorAll('.pset:not([hidden])')){let y=0;for(const c of ps.children){if(!c.classList.contains('on'))continue;const r=c.getBoundingClientRect();y=Math.max(y,(r.bottom-sr.top)/k)};if(y>1422)errs.push('panel bottom '+y.toFixed(0))}
const ps=[...document.querySelectorAll('.pset:not([hidden]) .el.on')].filter(e=>!e.querySelector('.stamp')&&!e.querySelector('.quote'));for(let i=0;i<ps.length;i++)for(let j=i+1;j<ps.length;j++){const a=ps[i].getBoundingClientRect(),b=ps[j].getBoundingClientRect();if(Math.min(a.bottom,b.bottom)-Math.max(a.top,b.top)>3)errs.push('el overlap '+ps[i].textContent.slice(0,20)+' | '+ps[j].textContent.slice(0,20))}
return errs}'''
out={}
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page(viewport={'width':1080,'height':2300})
    pg.goto('http://localhost:8765/index.html');pg.wait_for_timeout(1500)
    pg.evaluate("()=>{window.requestAnimationFrame=()=>0;document.querySelectorAll('*').forEach(e=>{e.style.transition='none';e.style.animation='none'})}")
    for t in times:
        e=pg.evaluate(JS,t)+pg.evaluate(JS2)
        if e: out[t]=sorted(set(e))
    shots=sys.argv[1:]
    for i,t in enumerate(shots):
        pg.evaluate("t=>render(+t)",t);pg.wait_for_timeout(250)
        pg.locator('#phone').screenshot(path=f'shot_{i}.png')
    b.close()
srv.kill()
for t,e in out.items(): print(t,e[:6])
print('checked',len(times),'bad',len(out))
