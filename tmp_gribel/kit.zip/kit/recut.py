import json,subprocess
C=json.load(open('clips.json'));src='/home/claude/hub/out/work.mp4';SP=1.2
for k,s,e in C:
    d=(e-s)/SP
    vf=f"delogo=x=426:y=150:w=96:h=34,crop=540:480:0:20,split[a][b];[a]scale=768:480:force_original_aspect_ratio=increase,crop=768:480,boxblur=20:2,eq=brightness=-0.08[bg];[bg][b]overlay=(W-w)/2:0,setpts=PTS/{SP},fps=30"
    subprocess.run(['ffmpeg','-y','-loglevel','error','-ss',str(s),'-to',str(e),'-i',src,'-filter_complex',vf,'-an','-c:v','libx264','-crf','22','-pix_fmt','yuv420p',f'{k}_v.mp4'],check=True)
    subprocess.run(['ffmpeg','-y','-loglevel','error','-ss',str(s),'-to',str(e),'-i',src,'-vn','-af',f'atempo={SP},highpass=f=90,acompressor=threshold=-20dB:ratio=3,loudnorm=I=-15,afade=t=in:d=0.08,afade=t=out:st={d-0.25:.3f}:d=0.25','-ar','44100','-ac','1',f'{k}.wav'],check=True)
subprocess.run('ffmpeg -y -loglevel error -f concat -safe 0 -i list.txt -c:v libx264 -crf 24 -g 15 -keyint_min 15 -pix_fmt yuv420p -movflags +faststart site/clips.mp4',shell=True,check=True)
subprocess.run('ffmpeg -y -loglevel error -ss 0.1 -i site/clips.mp4 -frames:v 1 -q:v 3 site/poster.jpg',shell=True,check=True)
subprocess.run('ffmpeg -y -loglevel error -ss 2 -i c1_v.mp4 -frames:v 1 chk.png',shell=True,check=True)
subprocess.run(['ffmpeg','-y','-loglevel','error','-i','/home/claude/hub/out/original_leve.mp4','-filter_complex','delogo=x=340:y=122:w=78:h=28','-c:v','libx264','-preset','slow','-crf','32','-g','48','-pix_fmt','yuv420p','-c:a','copy','-movflags','+faststart','site/original_leve.mp4'],check=True)
subprocess.run('ffmpeg -y -loglevel error -ss 1 -i site/original_leve.mp4 -frames:v 1 -q:v 4 site/original_leve.jpg',shell=True,check=True)
subprocess.run('ffmpeg -y -loglevel error -ss 20 -i site/original_leve.mp4 -frames:v 1 chk2.png',shell=True,check=True)
