import json, subprocess, os, re, sys
sys.path.insert(0, os.path.dirname(__file__))
from scenes import *
B = os.path.dirname(os.path.abspath(__file__))
HUB = '/home/claude/hub/out'
OUT = os.path.join(B, 'site'); os.makedirs(OUT, exist_ok=True)
GAP = 0.22

def dur(p):
    return float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',p]).decode())

clips = {k:(s,e) for k,s,e in json.load(open(os.path.join(B,'clips.json')))}
whisper = json.load(open(os.path.join(HUB,'words.json')))
# offsets in clips.mp4
voff = {}; acc = 0
for k,s,e in json.load(open(os.path.join(B,'clips.json'))):
    d = dur(os.path.join(B,f'{k}_v.mp4')); voff[k]=(acc,d); acc+=d

def norm(w): return re.sub(r'[^\wà-ú]','',w.lower())

def merge_spoken(words):
    out=[];i=0
    while i<len(words):
        hit=None
        for seq,disp in SPOKEN:
            if i+len(seq)<=len(words) and [norm(x['w']) for x in words[i:i+len(seq)]]==seq:
                tail=re.sub(r'[\wà-ú]','',words[i+len(seq)-1]['w'])
                hit=({'w':disp+tail,'s':words[i]['s'],'e':words[i+len(seq)-1]['e'],'raw':[x['w'] for x in words[i:i+len(seq)]]},len(seq));break
        if hit: out.append(hit[0]); i+=hit[1]
        else: out.append(dict(words[i])); i+=1
    return out

segs=[]; t=0.0; parts=[]
for typ,k in TIMELINE:
    if typ=='vo':
        p=os.path.join(HUB,'mark',f'{k}.mp3'); d=dur(p)
        wb=json.load(open(os.path.join(HUB,'mark',f'{k}.json')))
        from scenes import TTS_TEXT
        import difflib
        toks=TTS_TEXT[k].split()
        A=[norm(x['w']) for x in wb]; Bn=[norm(x) for x in toks]
        words=[None]*len(toks)
        for op,i1,i2,j1,j2 in difflib.SequenceMatcher(None,A,Bn,autojunk=False).get_opcodes():
            if op=='equal':
                for q in range(j2-j1): words[j1+q]={'w':toks[j1+q],'s':wb[i1+q]['s'],'e':wb[i1+q]['e']}
            elif op=='replace' or (op=='insert'):
                if i2>i1: s0,e0=wb[i1]['s'],wb[i2-1]['e']
                else:
                    s0=wb[i1-1]['e'] if i1>0 else 0; e0=wb[i1]['s'] if i1<len(wb) else s0+0.2
                n=j2-j1
                for q in range(n): words[j1+q]={'w':toks[j1+q],'s':s0+(e0-s0)*q/n,'e':s0+(e0-s0)*(q+1)/n}
        words=[{'w':re.sub(r'^[^\wà-úÀ-Ú]*','',x['w']) or x['w'],'s':round(t+x['s'],3),'e':round(t+x['e'],3)} for x in words]
        segs.append({'type':'vo','key':k,'start':round(t,3),'dur':round(d,3),'words':words})
        parts.append(('f',p))
    else:
        s,e=clips[k]; p=os.path.join(B,f'{k}.wav'); d=dur(p)
        ws=[]
        for x in whisper:
            if x['s']>=s-0.05 and x['e']<=e+0.1:
                w=FIX.get(x['w'],x['w'])
                if not w: continue
                if k=='c1' and x['w']=='da' and ws and ws[-1]['w']=='abaixo': ws[-1]['w']='abaixo,'; w='lá'
                if k=='c3' and x['w']=='da' and ws and ws[-1]['w']=='bombeiro': w='do'
                if k=='c3' and x['w']=='Amazônia': w='Amazonas'
                ws.append({'w':w,'s':round(t+(x['s']-s)/1.2,3),'e':round(t+(x['e']-s)/1.2,3)})
        segs.append({'type':'clip','key':k,'start':round(t,3),'dur':round(d,3),'words':ws,'voff':round(voff[k][0],3),'vdur':round(voff[k][1],3),'ctx':CLIP_CTX.get(k),'spk':CLIP_SPEAKER.get(k,'flavio')})
        parts.append(('f',p))
    t+=d+GAP; parts.append(('gap',GAP))
total=round(t,3)

# master audio
inputs=[];flt=[];n=0
for typ,v in parts:
    if typ=='f': inputs+=['-i',v]
    else: inputs+=['-f','lavfi','-t',str(v),'-i','anullsrc=r=44100:cl=mono']
    flt.append(f'[{n}:a]aresample=44100,aformat=channel_layouts=mono[a{n}]'); n+=1
fc=';'.join(flt)+';'+''.join(f'[a{i}]' for i in range(n))+f'concat=n={n}:v=0:a=1,loudnorm=I=-15[o]'
subprocess.run(['ffmpeg','-y','-loglevel','error',*inputs,'-filter_complex',fc,'-map','[o]','-ar','44100','-ac','1','-b:a','96k',os.path.join(OUT,'trilha.mp3')],check=True)

# resolve triggers
def find_word(seg, key):
    m=re.match(r'(.+?)(?:#(\d+))?$',key); w,nth=m.group(1),int(m.group(2) or 1)
    c=0
    for x in seg['words']:
        if norm(x['w']).startswith(norm(w)) and norm(w):
            c+=1
            if c==nth: return x['s']
    raise SystemExit(f'gatilho não achado: {seg["key"]} {key} :: '+' '.join(x['w'] for x in seg['words']))

def resolve(seg,key):
    if key.startswith('t:'): return round(seg['start']+float(key[2:]),3)
    return find_word(seg,key)

segd={s['key']:s for s in segs}
for s in segs:
    if s['type']!='vo': continue
    els=[]
    for at,html in PANELS.get(s['key'],[]):
        tt=resolve(s,at)
        html=re.sub(r'data-at="([^"]+)"',lambda m:f'data-t="{resolve(s,m.group(1))}"',html)
        els.append({'t':tt,'html':html})
    s['els']=els; s['src']=SRC.get(s['key'],'')
points=[{'t':find_word(segd[k],w),'kind':kind} for k,w,kind in POINTS]

# caption pages: two lines, <=24 chars
LINK={'o','a','e','em','de','do','da','um','uma','pra','no','na','que','com','os','as','dos','das','pro','por','se','ao'}
def pages(words):
    toks=[x for x in words]; out=[]; i=0
    while i<len(toks):
        lines=[[],[]]; stop=False
        for li in range(2):
            if stop: break
            ln=lines[li]
            while i<len(toks):
                cand=' '.join(x['w'] for x in ln+[toks[i]])
                if ln and len(cand)>26: break
                ln.append(toks[i]); i+=1
                if re.search(r'[.?!]$',toks[i-1]['w']) and len(' '.join(x['w'] for x in lines[0]+lines[1]))>=12: stop=True; break
            while len(ln)>1 and norm(ln[-1]['w']) in LINK and i<len(toks) and len(' '.join(x['w'] for x in ln[:-1]))>=12:
                i-=1; ln.pop()
        lines=[l for l in lines if l]
        if not lines: break
        out.append(lines)
    return [{'s':p[0][0]['s'],'e':p[-1][-1]['e'],'lines':[[{'w':x['w'],'s':x['s'],'e':x['e']} for x in l] for l in p]} for p in out]
for s in segs:
    ws=merge_spoken(s['words']) if s['type']=='vo' else s['words']
    s['cap']=pages(ws)

data={'total':total,'segs':segs,'points':points}
json.dump(data,open(os.path.join(B,'data.json'),'w'),ensure_ascii=False)
print('total',total, 'segs',len(segs))
for s in segs: print(s['type'],s['key'],s['start'],s['dur'])
